<?php
/** プラグイン名 */
define('PAYPAL_ACCESS_PLUGIN_NAME', 'PayPalAccess');
/** 非SSL環境での使用 */
//define('PAYPAL_ACCESS_PLUGIN_ALLOW_NOTSSL', false);