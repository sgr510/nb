DROP TABLE plg_paypalaccess_token;
DROP TABLE plg_paypalaccess_claims;
